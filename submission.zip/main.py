"""Kaggle Kaggriculture submission agent."""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict

_HERE = Path(__file__).resolve().parent if "__file__" in globals() else Path(os.getcwd())
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from agents.reasoning_agent import ReasoningAgent
from agents.questioning_agent import QuestioningAgent
from kaggriculture_adapter import parse_observation


class UnifiedSubmissionAgent:
    def __init__(self):
        self.reasoning = ReasoningAgent(memory_slots=30)
        self.questioning = QuestioningAgent(memory_slots=30)
        self._initialized = False

    def reset(self):
        self.reasoning.reset()
        self.questioning.reset()
        self._initialized = True

    def act(self, obs: Dict[str, Any], config: Dict[str, Any] | None = None) -> Dict[str, Any]:
        if not self._initialized:
            self.reset()

        parsed = parse_observation(obs)
        hour = int(parsed.get("hour", 0) or 0)

        if self.reasoning.may_act(hour):
            action = self.reasoning.act(parsed)
        elif self.questioning.may_act(hour):
            action = self.questioning.act(parsed)
        else:
            action = self.reasoning._farm_action(parsed)

        return action


_AGENT = UnifiedSubmissionAgent()


def agent(obs, config=None):
    return _AGENT.act(obs, config)
